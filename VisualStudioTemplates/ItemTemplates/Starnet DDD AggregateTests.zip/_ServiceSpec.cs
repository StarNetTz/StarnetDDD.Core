﻿using _DOMAIN_.Domain.$fileinputname$;
using _DOMAIN_.PL.Commands;
using _DOMAIN_.PL.Events;
using Starnet.Aggregates.Testing;
using System.Linq;
using System.Threading.Tasks;

namespace $rootnamespace$.$fileinputname$Tests
{
    internal class _ServiceSpec : ApplicationServiceSpecification<ICommand, IEvent>
    {
        protected override async Task<IEvent[]> ExecuteCommand(IEvent[] given, ICommand cmd)
        {
            var repository = new BDDAggregateRepository();
            repository.Preload(cmd.Id, given);
            var svc = new $fileinputname$ApplicationService(repository);
            await svc.Execute(cmd).ConfigureAwait(false);
            var arr = repository.Appended != null ? repository.Appended.Cast<IEvent>().ToArray() : null;
            return arr ?? new IEvent[0];
        }
    }
}