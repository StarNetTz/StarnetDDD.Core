﻿using NUnit.Framework;
using _DOMAIN_.PL.Commands;
using _DOMAIN_.PL.Events;
using System;
using System.Threading.Tasks;

namespace $rootnamespace$.$fileinputname$Tests
{
    class Create$fileinputname$Tests : _ServiceSpec
    {
        Create$fileinputname$ Create$fileinputname$Command;
        $fileinputname$Created $fileinputname$CreatedEvent;

        protected string AggregateId = "$fileinputname$s-1";

        [SetUp]
        public void Setup()
        {
            Create$fileinputname$Command = new Create$fileinputname$() { Id = AggregateId, IssuedBy = "zeko", Name = "Aggregate name", TimeIssued = DateTime.MinValue};
            $fileinputname$CreatedEvent = new $fileinputname$Created() { Id = AggregateId, IssuedBy = "zeko", Name = "Aggregate name", TimeIssued = DateTime.MinValue};
        }

        [Test]
        public async Task can_create_$fileinputname$()
        {
            Given();
            When(Create$fileinputname$Command);
            await Expect($fileinputname$CreatedEvent);
        }

        [Test]
        public async Task cannot_create_$fileinputname$_that_is_already_Createed()
        {
            Given($fileinputname$CreatedEvent);
            When(Create$fileinputname$Command);
            await ExpectError("$fileinputname$AlreadyExists");
        }
    }
}