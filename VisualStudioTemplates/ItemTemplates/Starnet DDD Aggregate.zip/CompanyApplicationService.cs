﻿using _DOMAIN_.PL.Commands;
using Starnet.Aggregates;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace $rootnamespace$.$fileinputname$
{
    public interface I$fileinputname$ApplicationService : IApplicationService { }

    public class $fileinputname$ApplicationService : I$fileinputname$ApplicationService
    {
        readonly IAggregateRepository AggRepository;

        public $fileinputname$ApplicationService(IAggregateRepository aggRepository)
        {
            AggRepository = aggRepository;
        }

        async Task CreateAgg(string id, Action<$fileinputname$Aggregate> usingThisMethod)
        {
            var agg = await AggRepository.GetAsync<$fileinputname$Aggregate>(id);
            if (agg != null)
                throw DomainError.Named("$fileinputname$AlreadyExists", string.Empty);
            agg = new $fileinputname$Aggregate(new $fileinputname$AggregateState());
            usingThisMethod(agg);
            await AggRepository.StoreAsync(agg);
        }

        public async Task Execute(object command)
        {
            await When((dynamic)command);
        }

        private async Task When(Create$fileinputname$ c)
        {
            await CreateAgg(c.Id, agg => agg.Create$fileinputname$(c));
        }
    }
}